<?php
/*
	Класс предназначен для обработки AJAX-запроса с клиента
	
	Принимает: ассоциативный массив следующего формата:
		$_POST = array(
			'searchAuthor'	 => searchAuthor,
			'searchArticle'	 =>	searchArticle,
			'searchCategory' =>	searchCategory,
			'searchYear'	 =>	searchYear
		);

	Выполняет 3 действия:
		
		1. Проверяет наличие хотя бы одного ненулевого параметра в присланном объекте (метод checkEmptyFields)
		
		2. Формирует строку запроса к БД (метод createQuery)
				1) в наличии базовая строка, выбирающая все данные из таблицы (кроме несуществующего id)
				2) в зависимости от наличия параметра в $_POST к строке запроса добавляется уточняющее условие

		3. Отправляет сформированную строку запроса (и мета-данные к ней) в АПИ (метод send)
*/
header('Content-type: text/html; charset=utf-8');

class HandlerAJAX {
	
	// проверка заполнения полей (хотя бы один параметр поиска в присланном объекте д.б. непустым)
	public static function checkEmptyFields($_POST)
	{
		// контроль инфо-потоков: выводим в файл данные, которые пришли с клиента от AJAX
		if (file_exists("handler.log")) { unlink("handler.log"); }		// предварительная очистка - дабы не плодить логи
		$log_str = 'Присланные от AJAX данные: ' . json_encode($_POST); // формируем строку логов
		file_put_contents("handler.log", $log_str, FILE_APPEND );		// пишем в файл

		// выполняем проверку заполнения параметров запроса
		if( 
			( isset($_POST['searchAuthor'])  && $_POST['searchAuthor'] 	== '' ) &&
			( isset($_POST['searchArticle']) && $_POST['searchArticle'] == '' ) &&
			( isset($_POST['searchCategory'])&& $_POST['searchCategory']== '' )	&&
			( isset($_POST['searchYear'])	 && $_POST['searchYear'] 	== '' )
		) return false;

		return true;
	}


	// ФОРМИРОВАНИЕ запроса к БД
	public static function createQuery($_POST)
	{

		// формируем базовый запрос (полная выборка из таблицы)
		$queryToDB = "SELECT * FROM archives_of_articles WHERE id NOT LIKE '00'"; // тестовая сходная запись запроса

		// формируем дополнительные уточняющие условия (в зависимости от количества параметров запроса)

				// если заполнено поле "автор"
				if( isset($_POST['searchAuthor']) 	&& $_POST['searchAuthor'] != '')
				{
					$queryToDB .= " AND author LIKE '" . $_POST['searchAuthor'] . "%'";			// ЧАСТИЧНЫЙ поиск по автору
				}

				// если заполнено поле "название статьи"
				if( isset($_POST['searchArticle']) 	&& $_POST['searchArticle'] != '')
				{
					$queryToDB .= " AND article_name LIKE '" . $_POST['searchArticle'] . "%'";	// ЧАСТИЧНЫЙ поиск по названию статьи
				}
				
				// если заполнено поле "категория"
				if( isset($_POST['searchCategory']) 	&& $_POST['searchCategory'] != '')
				{
					$queryToDB .= " AND category='" . $_POST['searchCategory'] . "'";			// поиск по категории
				}
				
				// если заполнено поле "год выпуска"
				if( isset($_POST['searchYear']) 	&& $_POST['searchYear'] != '')
				{
					$queryToDB .= " AND year=".$_POST['searchYear'];							// поиск по году выхода
				}
				
				$queryToDB .= " ORDER BY id DESC";

		// выводим в логи отчет: полностью сформированную строку запроса:
		$log_str = PHP_EOL . PHP_EOL . 'Сформированный запрос к БД: ' . $queryToDB; // формируем строку логов
		file_put_contents("handler.log", $log_str, FILE_APPEND );					// пишем в файл

		// возвращаем сформированный запрос (для отправки его в АПИ)
		return $queryToDB;
	}

	// ОТПРАВКА запроса к БД
	public static function sendQuery($dataToAPI)
	{
		// контроль исполнения: вывод логов
		$log_str = PHP_EOL . PHP_EOL . 'Адрес отправки данных: ' . json_encode($dataToAPI['url']); // формируем строку логов
		$log_str .= PHP_EOL . 'Посылаемые курлом данные: ' . json_encode($dataToAPI['data']); // формируем строку логов
		file_put_contents("handler.log", $log_str, FILE_APPEND );						// пишем в файл

		// преобразуем данные
		$url  = $dataToAPI['url'];
		$data = $dataToAPI['data'];
		
		// формируем дескриптор
		$ch = curl_init();
		
		// настройки запроса
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // выводим ответ в переменную
		
		// реализуем запрос, и заносим ответ в переменную
		$result = curl_exec($ch);
		
		// закрываем соединение (удаляем дескриптор)
		curl_close($ch);

		return $result;
	}
} // end of HandlerAJAX


/////////////////////////////////////////////////////////////////////////////////////////////////////

// если ВСЕ поля пустые (дублирующая проверка на сервере)
if( !HandlerAJAX::checkEmptyFields($_POST) )
{
	echo "<p style='color:red'>Должно быть заполнено хотя бы одно поле!</p>";
	exit();
}

// формируем запрос к БД (на основе данных, которые пришли от AJAX-запроса в массиве $_POST)
$queryToDB = HandlerAJAX::createQuery($_POST);					// для теста:	$queryToDB = "SELECT * FROM archives_of_articles WHERE id NOT LIKE '00' AND year=2010 ORDER BY id DESC";

// упаковываем сформированный к БД запрос в объект для отправки на внешний сайт (это чисто для php-curl)
$dataToAPI = array(
	'url'	=> 'http://zarchon.bget.ru/search_articles/server_api.php',
	'data'	=> array('querySearch'=>'YBS', 'queryToDB'=>$queryToDB)
);

// посылаем запрос на внешний сайт с помощью АПИ  и заносим ответ в переменную
$total = HandlerAJAX::sendQuery($dataToAPI);

// выводим на экран ответ АПИ сервиса, здесь его подхватит AJAX
echo $total;



















/*


																	
																	
																	
// получаем статьи из БД в виде ассоц. массива
$searchResult = SearchArticlesDB::getSearchArticles($queryToDB);

// сериализуем массив статей
$dataToSend   = json_encode($searchResult);

echo $dataToSend;
*/