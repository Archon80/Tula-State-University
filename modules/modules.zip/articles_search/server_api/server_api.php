<?php
// устанавливаем правильную кодировку
header('Content-type: text/html; charset=utf-8');

// подключаем класс для работы с БД
include_once "libs/search_articles.db.php";

// логируем контроль приходящих данных
// выводим присланные от AJAX данные в логи
if (file_exists("report.log")) { unlink("report.log"); }									// предварительная очистка - дабы не плодить логи
$log_str = PHP_EOL . PHP_EOL . 'Присланные от клиента данные: ' . json_encode($_REQUEST); 	// формируем строку логов
file_put_contents("report.log", $log_str, FILE_APPEND );									// пишем в файл

//----------------------------------------------------------------

// формируем запрос к БД (считываем из POST-запроса от АПИ клиента)
$queryToDB = $_REQUEST['queryToDB'];

// получаем ассоциативный массив запрашиваемых статей
$searchResult = SearchArticlesDB::getSearchArticles($queryToDB);

// сериализуем массив с строку для отправки по сети
$dataToSend   = json_encode($searchResult);

// выводим сериализованный массив (его подхватывает PHP-curl, который ждет ответа)
echo $dataToSend;















/*
	// ОТЛАДКА
	
	// 1) тестовый запрос к БД				при отладке КЛАССА ДЛЯ РАБОТЫ С БД
	$queryToDB = "SELECT * FROM archives_of_articles WHERE id NOT LIKE '00'";
	
	// 2) тестирование работы страницы 		при отладке АПИ
	if ($_REQUEST['querySearch'] == "YBS")
	{
		echo "<pre>"; print_r($_REQUEST); echo '</pre>';
	}
*/















