<?php
/*
	ПОЛУЧЕНИЕ СТАТЕЙ ИЗ БАЗЫ ДАННЫХ
*/
class SearchArticlesDB
{
	// получение запроса, выборка, обработка выборки
	public static function getSearchArticles($query)
	{
		self::dbConnect();
		$arts = self::getArticlesFromDB($query);
		return self::processArticlesFromDB($arts);
	}
	
	// подключение к БД
	private static function dbConnect()
	{
		// устанавливаем начальные значения для подключения к БД (если еще раз затрешь)
		define('DB_HOST', 'localhost');
		define('DB_LOGIN', 'zarchon_80');
		define('DB_PASSWORD', '290980');
		define('DB_NAME', 'zarchon_80');

		// настройка языка и временной зоны
		setlocale(LC_ALL, 'ru_RU.65001');
		date_default_timezone_set('Europe/Moscow');
		
		// подключение к БД
		mysql_connect(DB_HOST, DB_LOGIN, DB_PASSWORD) or die('No 1 connect with data base');
		mysql_query('SET NAMES utf8');
		mysql_select_db(DB_NAME) or die('No data base');
	}

	// выборка статей из БД
	private static function getArticlesFromDB($q)
	{
		// формирование запроса										// тестовый запрос: $query = "SELECT * FROM archives_of_articles WHERE id NOT LIKE '0' AND author='YBS'";
		$query = $q;

		// реализация запроса
		$result = mysql_query($query);
		if(!$result) die('Ошибка базы данных: ' . mysql_error());	// при разработке - вывод ошибки, после - нет

		return $result;
	}

	// обработка выборки: возвращает ассоциативный массив статей
	private static function processArticlesFromDB($arts)
	{
		// получаем количество строк, которые вернул запрос
		$n = mysql_num_rows($arts);	// ТОЛЬКО для SELECT или SHOW (для INSERT, UPDATE, REPLACE и DELETE - mysql_affected_rows() )
		
		// формируем пустой массив для выкачиваемых из БД статей
		$articles = array();

		// обрабатываем ответ БД (набор массивов - по каждой строке), превращая его в набор массивов
		for ($i = 0; $i < $n; $i++)
		{
			$row = mysql_fetch_assoc($arts);
			$articles[] = $row;
		} // или while ($row = mysql_fetch_array($arts)) { $articles[] = $row; }
		
		// возвращаем АССОЦИАТИВНЫЙ МАССИВ статей (который сможет обработать РНР)
		return $articles;
	}
}




/*
	МОЙ сайт (цветочный)
	--------------------
	define('DB_HOST', 'localhost');
	define('DB_LOGIN', 'zarchon_80');
	define('DB_PASSWORD', '290980');
	define('DB_NAME', 'zarchon_80');

	ТВОЙ сайт (Петерхост)
	---------------------
	define('DB_HOST', 'mysql.boryak.z8.ru');
	define('DB_LOGIN', 'dbu_boryak_3');
	define('DB_PASSWORD', '5NPVpkC3XBL');
	define('DB_NAME', 'db_boryak_3');
	
	Еще раз перезатрешь мои данные - убью!!! )))
*/
