document.querySelector('#search-data-send').onclick = function()
{
	(function getStart() {

		var dataFromForm = getDataFromSearchForm();

		if( !dataFromForm )		alert('Должно быть заполнено хотя бы одно поле!');
		else					sendQueryToServer(dataFromForm);
	})();

	// функция собирает данные из формы (генерация предупреждения, или упаковка их в объект для отправки)
	function getDataFromSearchForm()
	{		
		// получаем значения введенных пользователем параметров поиска
		var searchAuthor 	 = document.querySelector('#search-author-input-text').value,
			searchArticle	 = document.querySelector('#search-article-name-textarea').value,
			searchCategory	 = document.querySelector('#search-category-list').value,
			searchYear		 = document.querySelector('#search-years-list').value;

		// если все поля пустые - выводим алерт и прекращаем работу сценария
		if( 
			searchAuthor 	== '' && 
			searchArticle 	== '' && 
			searchCategory 	== '' && 
			searchYear 		== '' 
		) {
			return false;
		}
		
		// возвращаем считанные данные в формате объекта
		return {
			searchAuthor		: searchAuthor,
			searchArticle		: searchArticle,
			searchCategory		: searchCategory,
			searchYear			: searchYear
		};
	}
	
	// посылаем данные на сервер с помощью AJAX (сердце Леса)
	function sendQueryToServer(paramsToServer)
	{
		console.log('AJAX шлет параметры на сервер: ', paramsToServer);	// контроль: данные, посылаемые AJAX-ом
		ajax.post({
			url:        'views/pages/articles_search/client_api.php',
			data:       paramsToServer,
			success:    funcSuccess,
			error:      funcError
		});
	}

	// функция отрабатывает с случае удачного AJAX-запроса
	function funcSuccess(args)
	{
		// делаем видимым шапку таблицы
		document.querySelector('#search-page-result').classList.remove('hide');

		// принимаем ответ сервера, преобразуем его из строки в объект
		var objArts = JSON.parse(args.text);
		
		// контроль: выводим в консоль ответ сервера
		console.log( 'Ответ сервера: ');
		for(elem in objArts) { console.log( objArts[elem] ); }

		// динамически генерируем тело таблицы с результатами запроса
		putArtsIntoPage(objArts);

		//-----------------------------------------------------------------------

		// динамическая генерация полей таблицы с результатами запроса
		function putArtsIntoPage(objArts)
		{
			// получаем ДОМ-элемент: тело таблицы, куда будут динамически подставляться генерируемые элементы
			var searchResultTable = document.querySelector('#table-arts-search-result-body');
			
			// предварительно очищаем тело таблицы, чтобы запросы не плодились
			searchResultTable.innerHTML = '';
			
			// циклически заполняем тело таблицы элементами
			for(var i = 0; i < objArts.length; i++)
			{
				
				var newTR = document.createElement('tr');
				
				// вставляем автора статьи
				var tdAuthor 		= document.createElement('td');
				tdAuthor.className 	= 'tidings-table-author';
				tdAuthor.innerHTML 	= objArts[i]['author'];
				newTR.appendChild(tdAuthor);
				
				// вставляем название статьи
				var tdArticleName 		= document.createElement('td');
				tdArticleName.className 	= 'tidings-table-article-name';
				tdArticleName.innerHTML 	= objArts[i]['article_name'];
				newTR.appendChild(tdArticleName);
				
				// вставляем название категории
				var tdСategory 		= document.createElement('td');
				tdСategory.className 	= 'tidings-table-category';
				tdСategory.innerHTML 	= objArts[i]['category'];
				newTR.appendChild(tdСategory);
				
				// вставляем год
				var tdYear 		= document.createElement('td');
				tdYear.className 	= 'tidings-table-year';
				tdYear.innerHTML 	= objArts[i]['year'];
				newTR.appendChild(tdYear);
				
				// вставляем год
				var tdStatus 		= document.createElement('td');
				tdStatus.className 	= 'tidings-table-status';
				tdStatus.innerHTML 	= objArts[i]['status'];
				newTR.appendChild(tdStatus);

				// формируем табличную ячейку под ссылку
				var tdLink 			= document.createElement('td');
				tdLink.className 	= 'tidings-table-filename';					
					// формируем ссылку в эту табличную ячейку
					var tdAnchor		= document.createElement('a');
					tdAnchor.href		 	= '#bottom';
					//tdAnchor.onclick		= function(){alert(123);};
					tdAnchor.onclick		= "load_pdf_therest(" + objArts[i]['file_name'] + ');';
					tdAnchor.innerHTML 	= 'Посмотреть';
					tdLink.appendChild(tdAnchor);
				newTR.appendChild(tdLink);
				
/*				
				// вставляем имя файла
				var tdFilename 			= document.createElement('td');
				tdFilename.className 	= 'tidings-table-filename';
				tdFilename.innerHTML 	= objArts[i]['file_name'];
				newTR.appendChild(tdFilename);
				
				// вставляем страницы
				var tdPages 		= document.createElement('td');
				tdPages.className 	= 'tidings-table-pages';
				tdPages.innerHTML 	= objArts[i]['article_page'];
				newTR.appendChild(tdPages);
*/
				searchResultTable.appendChild(newTR);
			} // end of cycle
		} // end of putArtsIntoPage()
	}
	
	// функция отрабатывает с случае ошибочного AJAX-запроса
	function funcError(args)
	{
		console.log('Случилась какая-то херня');
	}
}