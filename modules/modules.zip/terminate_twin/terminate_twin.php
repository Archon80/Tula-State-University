<?php

	ob_start();

		

		$res = 'Итог: ответ сервера';
		include 'terminate_twin.html';
	
	$page = ob_get_clean();

	echo $page;