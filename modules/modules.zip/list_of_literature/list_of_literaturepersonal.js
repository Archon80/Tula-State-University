var mainDiv				= document.querySelector('#mainBlock');				// пишем в переменную главный блок страницы

// добавление очередной записи в список литературы
function addStringToList(inputsName, cb)
{
	
	if ( !checkFormFields(inputsName) )
	{
		alert('Должны быть заполнены все поля формы');
		return;
	}

	var divWithText = createNewDiv( cb() );		// генерируем новый блок, вставляем в него текстовый узел
	insertDivInList(divWithText);							// вставляем полностью готовый див (с данными пользователя) на страницу
	localStorage.myData = mainDiv.innerHTML;				// заносим обновленные данные в хранилище
	clearFormFields(inputsName);				// обнуляем значения полей

	////////////////////////////////////////////////////////////////////////////////////////////////////////

	// проверка заполнения полей формы
	function checkFormFields(inputsName)
	{
		
		var fields = document.getElementsByClassName(inputsName),
			fill = true;						// возвращаемая переменная-индикатор
		
		for (var i = 0; i < fields.length; i++)
		{
			if (fields[i].value == '')		fill = false;
		}
		
		return fill;
	}

	// очистка полей формы (обходим циклом все поля, очищаем значения)
	function clearFormFields(inputsName)
	{
		var fields = document.getElementsByClassName(inputsName);

		for (var i = 0; i < fields.length; i++) {
			fields[i].value = '';
		}
	}

	// генерируем новый блок и вставляем его на страницу
	function createNewDiv( text )
	{
		var newDivTemplate 			= document.createElement('div');
		newDivTemplate.className 	= 'newDivClass';
		newDivTemplate.style 	 	= 'margin:0 5px; padding: 3px 0 0 3px;';

		newDivTemplate.innerHTML = text;									// текст - в шаблонный див

		return newDivTemplate;
	}
	
	// подпихиваем сгененированный див с текстом в список на странице
	function insertDivInList(newDivTemplate)
	{
		mainDiv.appendChild(newDivTemplate);									// шаблонный див - в исходный див
	}		

}; // окончание добавления блока

// полная очистка данных (и список, и локальное хранилище)
function clearListAndStorage()
{
	mainDiv.innerHTML = '';
	localStorage.removeItem('myData');		//localStorage.clear;     // delete localStorage.myData;  // localStorage.removeItem('myData');
};

// удаление последней записи
function deleteLastString()
{
	
	mainDiv.removeChild(mainDiv.lastChild);
	
	localStorage.myData = mainDiv.innerHTML;	// перезапись обновленного содержимого блока в локальное хранилище
	
};

// извлекаем данные из локального хранилища, помещаем их на страницу (нужно на случай НОВОГО захода на страницу, иначе список будет пустым)
function getDataFromStorageToPage()
{
	mainDiv.innerHTML = localStorage.getItem('myData');
}