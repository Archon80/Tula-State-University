/*
	Здесь перечислены функции, общие для всех списков литературы.
	Чтобы избежать конфликтов, упакуем их в объект.
*/

var mainDiv	= document.querySelector('#mainBlock');				// пишем в переменную главный блок страницы

var LIST = {

	// добавление очередной записи в список литературы
	addStringToList: function(inputsName, lsName, cb) {
		
			if ( !checkFormFields(inputsName) )
			{
				alert('Должны быть заполнены все поля формы');
				return;
			}

			var divWithText = createNewDiv( cb() );		// генерируем новый блок, вставляем в него текстовый узел (cb - функция опроса форм и генерации строки, подключается из сценария personal.js)
			insertDivInList(divWithText);				// вставляем полностью готовый див (с данными пользователя) на страницу
			localStorage[lsName] = mainDiv.innerHTML;	// заносим обновленные данные в хранилище
			clearFormFields(inputsName);				// обнуляем значения полей

			////////////////////////////////////////////////////////////////////////////////////////////////////////

			// проверка заполнения полей формы
			function checkFormFields(inputsName)
			{
				
				var fields = document.getElementsByClassName(inputsName),
					fill = true;						// возвращаемая переменная-индикатор
				
				for (var i = 0; i < fields.length; i++)
				{
					if (fields[i].value == '')		fill = false;
				}
				
				return fill;
			}

			// очистка полей формы (обходим циклом все поля, очищаем значения)
			function clearFormFields(inputsName)
			{
				var fields = document.getElementsByClassName(inputsName);

				for (var i = 0; i < fields.length; i++) {
					fields[i].value = '';
				}
			}

			// генерируем новый блок и вставляем его на страницу
			function createNewDiv( text )
			{
				var newDivTemplate 			= document.createElement('div');
				newDivTemplate.className 	= 'newDivClass';
				newDivTemplate.style 	 	= 'margin:0 5px; padding: 3px 0 0 3px;';

				newDivTemplate.innerHTML = text;									// текст - в шаблонный див

				return newDivTemplate;
			}
			
			// подпихиваем сгененированный див с текстом в список на странице
			function insertDivInList(newDivTemplate)
			{
				mainDiv.appendChild(newDivTemplate);									// шаблонный див - в исходный див
			}		

	}, // окончание добавления блока

	// полная очистка данных (и список, и локальное хранилище)
	clearListAndStorage: function(lsName) {
		mainDiv.innerHTML = '';
		localStorage.removeItem(lsName);		//localStorage.clear;     // delete localStorage.myData;  // localStorage.removeItem('myData');
	},

	// удаление последней записи
	deleteLastString: function(lsName) {		
		mainDiv.removeChild(mainDiv.lastChild);		
		localStorage[lsName] = mainDiv.innerHTML;	// перезапись обновленного содержимого блока в локальное хранилище
	},

	// извлекаем данные из локального хранилища, помещаем их на страницу (нужно на случай НОВОГО захода на страницу, иначе список будет пустым)
	getDataFromStorageToPage: function(lsName) {
		mainDiv.innerHTML = localStorage.getItem(lsName);
	}

};



/*
	РАБОТАЕМ СО СВОЙСТВАМИ С ДАННЫМИ
	--------------------------------
		Делаем так, чтобы свойства объекта LIST нельзя было перезаписать или удалить
*/
function fixObjProperties(obj)
{
	for(var elem in obj)
	{
		Object.defineProperty(obj, elem, { writable: false });			// нельзя перезаписать
		Object.defineProperty(obj, elem, { configurable: false });		// нельзя удалить (и переконфигурировать)
	}
}

fixObjProperties(LIST);

console.log( '111111111111111111111111111111111111111' );
var i = 0;
delete LIST.clearListAndStorage;
for(var elem in LIST)
{
	//console.log( elem + ':' + LIST[elem] );
	console.log( ++i );
}


console.log( '222222222222222222222222222222222222222' );

