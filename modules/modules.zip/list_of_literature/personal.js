/*
	Считываем значения заполненных полей формы, формируем из них строку
	Перечисленные ниже функции - очень индивидуальны, у них мало общего - прежде всего ввиду группировки итоговых данных (знаки препинания и т.п.)
*/


// для формы №1
function createString()
{
	// считываем в переменные значения всех текстовых полей
	var textFieldAuthor 	 	= document.querySelector('#author').value,
		textFieldInitials 	 	= document.querySelector('#initials').value,
		textFieldArticleName 	= document.querySelector('#article_name').value,
		textFieldArticleType 	= document.querySelector('#article_type').value,
		textFieldPublicNumber 	= document.querySelector('#public_number').value,
		textFieldPublicHouse 	= document.querySelector('#public_house').value,
		textFieldYear			= document.querySelector('#year').value,
		textFieldPages 			= document.querySelector('#pages').value;

	// формируем итоговую строковую переменную (согласно нужному протоколу)
	var totalVar = 	textFieldAuthor + " " + textFieldInitials + " " +
			textFieldArticleName + ": " + textFieldArticleType + ". " + textFieldPublicNumber +
			" " + textFieldPublicHouse + ", " + textFieldYear + ". " + textFieldPages + " с.";
	
	return totalVar;
}