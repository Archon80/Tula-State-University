<?php
	$x = 5;

	function f1()
	{
		echo $x;
	}

	f1();