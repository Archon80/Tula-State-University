<?php
	/*
		КОНТРОЛЛЕР (админская часть) - удаление статьи
	*/
	include_once('model/start.php');


	// call MODEL

		// шаблонные объявления
		$template_modules['title']	= 'Удаление статьи';
		$template_modules['h1'] 	= 'Удаление статьи';

		// объявление используемых в сценарии переменных
		$id_art 		= '';				// гет-параметр
		$id_article 	= '';				// идентификатор статьи из БД
		$author			= '';
		$article_name	= '';
		$category 		= '';
		$year			= '';
		$status			= '';
		$filename		= '';
		$article_page	= '';
		$notes			= '';
		$user_id		= '';
		
		$delete = false;
		$error  = false;					// выводимые предупреждения

		// перешли из редактора
		if( isset($_GET['id_art']) ) {

			// получение статьи
			$article = article_get($_GET['id_art']);
			
			// вывод данных статьи в переменные, видимые модели (и потом - вывести, и не давать редактировать)
			$id_article 	= $article['id'];
			$author			= $article['author'];
			$article_name	= $article['article_name'];
			$category 		= $article['category'];
			$year			= $article['year'];
			$status			= $article['status'];
			$filename		= $article['filename'];
			$article_page	= $article['article_page'];
			$notes			= $article['notes'];
			$user_id		= $article['user_id'];

			// чтобы сгенерировалось последнее предупреждение клиенту
			$delete = true;
		}
		// пользователь уверенно хочет удалить статью
		else if(  isset($_POST['delete']) && isset($_POST['hidden']) )
		{
			// удаляем статью (ее идентификатор получаем из скрытого поля)
			$result = article_delete($_POST['hidden']);

			// готовим сообщение о результатах работы сценария
			if($result)		$_SESSION['article_has_deleted'] = 'ok';
			else			$_SESSION['article_has_deleted'] = 'err';

			// редиректим пользователя обратно в редактор
			header('Location: index.php');
			exit();
		}
		// пользователь передумал, и хочет вернуться в редактор
		else if(  isset($_POST['return']) )
		{
			header('Location: index.php');
			exit();
		}

	// call VIEW

		// основной шаблон (включает 3 блока)
		$base_content = include_templates('views/tpl_article_delete.html',
			array(
				'id_article' 	 => $id_article,
				'author' 		 => $author,
				'article_name' 	 => $article_name,
				'category' 		 => $category,
				'year' 			 => $year,
				'status' 		 => $status,
				'filename' 		 => $filename,
				'article_page'	 => $article_page,
				'notes' 		 => $notes,
				'user_id' 		 => $user_id,

				'error'		 	 => $error,
				'delete'		 => $delete
			)
		);

		echo total_render($base_content, $template_modules);