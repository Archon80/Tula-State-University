<body bgcolor=000000>

<?php
echo "
<center><br><br>
<img src=img/chip_deyl.jpg width=85%>
</center>
";
?>