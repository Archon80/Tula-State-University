<?php
	/*
		КОНТРОЛЛЕР (служебный) - создание одной статьи
	*/
	include_once('model/start.php');

	
	// call MODEL

		// шаблонные объявления
		$template_modules['title']	= 'Добавление статьи';
		$template_modules['h1'] 	= 'Добавление статьи';

		// переменные сценария
		$author			= '';
		$article_name	= '';
		$category 		= '';
		$year			= '';
		$status			= '';
		$file_name		= '';
		$article_page	= '';
		$notes			= '';
		$user_id		= '';
		$error	 		= false;		// индикатор: правильно ли заполнены поля формы
		//$double 	 	= false;		// индикатор: дублирование статьи

		// ВЕТКА №1: перешли на страницу методом ПОСТ (данны были отправлены из формы ЭТОЙ ЖЕ страницы)
		if ( !empty($_POST) )
		{
			// контрольный вывод логов
			//$str_to_log = PHP_EOL.date(DATE_RFC2822).PHP_EOL.'Файл article_new.php (добавление статьи) - данные из формы, массив POST: '.PHP_EOL. json_encode($_POST);
			//file_put_contents("article_new.log", $str_to_log, FILE_APPEND );


			// если сработала проверка на дубли
			if ( checkDouble( $_POST['author'], $_POST['article_name'], $_POST['category'], $_POST['year'] ) )
			{
				$_SESSION['article_has_added'] = 'double';

				header('Location: index.php');
				exit();
			}

			// поля заполнены верно
			if (
				checkTitle( $_POST['author'] ) 	&&
				checkTitle( $_POST['article_name'] ) 
				//checkDouble( $_POST['author'], $_POST['article_name'], $_POST['category'], $_POST['year'] )
			)
			{
				// готовим данные для передачи в функцию добавления статьи
				$arrDataToAdd = array(
					'author' 		=> $_POST['author'],
					'article_name' 	=> $_POST['article_name'],
					'category' 		=> $_POST['category'],
					'year' 			=> $_POST['year'],
					'status' 		=> $_POST['status'],
					'file_name' 	=> $_POST['file_name'],
					'article_page' 	=> $_POST['article_page'],
					'notes' 		=> $_POST['notes'],
					'user_id' 		=> $_POST['user_id']
				);

				// добавляем статью
				$result = article_add($arrDataToAdd);	// Сердце Леса
				
				// передаем в файл редактора сообщение об итоге операции добавления статьи
				if($result)		$_SESSION['article_has_added'] = 'ok';
				else			$_SESSION['article_has_added'] = 'err';
				
				// завершаем работу сценария
				header('Location: index.php');
				exit();
			}
			// поля заполнены неверно
			else
			{
				// включаем ошибку (это будет отображено в верстке)
				$error = true;
				
				// сохраняем уже введенные данные в полях формы
				$author			= $_POST['author'];
				$article_name	= $_POST['article_name'];
				$category 		= $_POST['category'];
				$year			= $_POST['year'];
				$status			= $_POST['status'];
				$file_name		= $_POST['file_name'];
				$article_page	= $_POST['article_page'];
				$notes			= $_POST['notes'];
				$user_id		= $_POST['user_id'];
			}
		}
		// если на страницу зашли методом ГЕТ (перешли из редактора)
		else
		{
			// просто очищаем поля формы
			$author			= '';
			$article_name	= '';
			$category 		= '';
			$year			= '';
			$status			= '';
			$file_name		= '';
			$article_page	= '';
			$notes			= '';
			$user_id		= '';
		}
	
	// call VIEW

		// основной шаблон (включает 3 блока)
		$base_content = include_templates('views/tpl_article_new.html',
			array(
				'author' 		=> $author,
				'article_name' 	=> $article_name,
				'category' 		=> $category,
				'year' 			=> $year,
				'status' 		=> $status,
				'file_name' 	=> $file_name,
				'article_page'	=> $article_page,
				'notes' 		=> $notes,
				'user_id' 		=> $user_id,

				'error'			=> $error,
				'arrDataToAdd'	=> $arrDataToAdd
			)
		);

		echo total_render($base_content, $template_modules);
