<?php
	/*
		КОНТРОЛЛЕР (админская часть) - редактирование статьи
	*/
	include_once('model/start.php');


	// call MODEL

		// шаблонные объявления
		$template_modules['title']	= 'Редактирование статьи';
		$template_modules['h1'] 	= 'Редактирование статьи';

		// переменные сценария
		$id_art 		= '';								// гет-параметр
		$id_article 	= '';								// идентификатор статьи из БД
		$author			= '';
		$article_name	= '';
		$category 		= '';
		$year			= '';
		$status			= '';
		$file_name		= '';
		$article_page	= '';
		$notes			= '';
		$user_id		= '';
		
		$incorrectFormFill = false;				// выводимое предупреждение

		// перешли из редактора
		if( isset($_GET['id_art']) ) {

			// получение статьи
			$article = article_get($_GET['id_art']);
			
			//echo '<pre>'; print_r($article); echo '</pre>'; 			exit();
			
			// вывод данных статьи в переменные, видимые модели - чтобы было что редактировать, гыгы (проверочное условие не нужно - реализовано в модели)
			$id_article 	= $article['id'];
			$author			= $article['author'];
			$article_name	= $article['article_name'];
			$category 		= $article['category'];
			$year			= $article['year'];
			$status			= $article['status'];
			$file_name		= $article['file_name'];
			$article_page	= $article['article_page'];
			$notes			= $article['notes'];
			$user_id		= $article['user_id'];
			
			//echo '1111' . $file_name; exit();
		}
		// сохранение измененной статьи
		else if(  isset($_POST['save']) && isset($_POST['hidden']) )
		{
			// проверяем правильность заполнения форм
			if( checkTitle( $_POST['author'] ) && checkTitle( $_POST['article_name'] ) ) {

				// готовим данные к отдаче в функцию
				$arrDataToUpd = array(
					'id_article' 	 => $_POST['hidden'],
					'author' 		 => $_POST['author'],
					'article_name' 	 => $_POST['article_name'],
					'category' 		 => $_POST['category'],
					'year' 			 => $_POST['year'],
					'status' 		 => $_POST['status'],
					'file_name' 	 => $_POST['file_name'],
					'article_page'	 => $_POST['article_page'],
					'notes' 		 => $_POST['notes'],
					'user_id' 		 => $_POST['user_id']
				);
				
				

				// обновляем статью
				$result = article_update($arrDataToUpd);

				// готовим сообщение о результатах работы сценария
				if($result)		$_SESSION['article_has_changed'] = 'ok';
				else			$_SESSION['article_has_changed'] = 'err';

				// редиректим пользователя обратно в редактор
				header('Location: index.php');
				exit();
			}
			else
			{
				$id_article 	 = $_POST['hidden'];
				$author 		 = $_POST['author'];
				$article_name 	 = $_POST['article_name'];
				$category 		 = $_POST['category'];
				$year 			 = $_POST['year'];
				$status 		 = $_POST['status'];
				$file_name 		 = $_POST['file_name'];
				$article_page	 = $_POST['article_page'];
				$notes 		 	 = $_POST['notes'];
				$user_id 		 = $_POST['user_id'];
				
				$incorrectFormFill = true;
			}
		}

	// call VIEW
		
		// основной шаблон (включает 3 блока)
		$base_content = include_templates('views/tpl_article_edit.html',
			array(
				'id_article' 	 	=> $id_article,
				'author' 		 	=> $author,
				'article_name' 	 	=> $article_name,
				'category' 		 	=> $category,
				'year' 			 	=> $year,
				'status' 		 	=> $status,
				'file_name' 		=> $file_name,
				'article_page'	 	=> $article_page,
				'notes' 		 	=> $notes,
				'user_id' 		 	=> $user_id,

				'incorrectFormFill' => $incorrectFormFill
			)
		);

		echo total_render($base_content, $template_modules);