<?php
/*
	Объект, который приходит:
	------------------------
	'user'  =>  array(
	                'userEmail'   => $_SERVER['email'],
	                'operation'   => $_SERVER['operation'],
	                'group'       => $_SERVER['group'],
	                'groupMove'   => $_SERVER['groupMove']
                )

    Объект для работы АПИ
    ---------------------
    'user'  =>  array(
	                'userEmail'   => $_SERVER['email'],
	                'operation'   => $_SERVER['operation'],
	                'group'       => $_SERVER['group'],
	                'groupMove'   => $_SERVER['groupMove']
                ),
    'admin' => array(
		            'user_id'       => 'prodavecokon',
		            'user_rps_key'  => '6067040551137e729d651aab1d3de829',
        		)

*/
class JustClickSubscribe
{
	public static function process($data)
	{
		// ФОРМИРУЕМ ДАННЫЕ ДЛЯ ОТПРАВКИ
			// данные админа
			$user_rs = $data['admin'];	//echo '<pre>'; print_r($data); echo '</pre>'; exit();

			// объект данных о пользователе (для отправки на сервер)
			$send_data = array(
				'rid[0]' 		    => $data['user']['group'],	// если простое удаление - работаем с группой №1; если перемещение - работаем с группой №2
				'lead_email' 	    => $data['user']['userEmail']
			);

    			//file_put_contents("JustClickSubscribe.log", json_encode($send_data) );

			// формируем электронную подпись: хешируем логин и ключ админа
			$send_data['hash'] = self::GetHash($send_data, $user_rs);
	}


	// 1-ая основная функция: ДОБАВЛЕНИЕ пользователя
	//public static function addUser($data, $op)
	public static function addUser($data)
	{
		// ФОРМИРУЕМ ДАННЫЕ ДЛЯ ОТПРАВКИ

			// формируем данные

					// данные админа
					$user_rs = $data['admin'];	//echo '<pre>'; print_r($data); echo '</pre>'; exit();

					// объект данных о пользователе (для отправки на сервер)
					$send_data = array(
						'rid[0]' 		    => $data['user']['group'],	// если простое удаление - работаем с группой №1; если перемещение - работаем с группой №2
						'lead_email' 	    => $data['user']['userEmail']
					);

					// формируем электронную подпись: хешируем логин и ключ админа
					$send_data['hash'] = self::GetHash($send_data, $user_rs);

			// пишем лог отправляемых в АПИ данных
			self::Log( PHP_EOL.'04. Файл justClickSubscribe.php (добавление файла) - данные в АПИ: '. json_encode($send_data) );
			//$data_from_renderPHP = PHP_EOL.'04. Файл justClickSubscribe.php (добавление файла) - данные в АПИ: '. json_encode($send_data);
			//file_put_contents("php/WidgetForms/data_from_client.log", $data_from_renderPHP, FILE_APPEND );

		//	ОТПРАВЛЯЕМ ДАННЫЕ

			// отправляем курлом сформированные данные на нужный адрес СПИ
			// затем декодирум JSON-ответ, и заносим результат в перемнную
			$resp = json_decode(self::Send('http://prodavecokon.justclick.ru/api/AddLeadToGroup', $send_data));

		//	ПРОВЕРЯЕМ ОТВЕТ СЕРВИСА

				// проверяем правильность подписи (в ответе сервера)
				if( !self::CheckHash($resp, $user_rs) )
				{
					self::Log( PHP_EOL.'05. Файл justClickSubscribe.php (добавление файла) - ответ сервиса: '. json_encode("Ошибка! Подпись к ответу не верна!") );
					return "Ошибка! Подпись к ответу не верна!";
					exit;
				}

				// если подпись правильная - операция будет выполнена, смотрим ее результат
				if($resp->error_code == 0) {
					self::Log( PHP_EOL."05. Файл justClickSubscribe.php (добавление файла) - ответ сервиса: пользователь {$data['user']['userEmail']} добавлен в группу {$send_data['rid[0]']}. Ответ сервиса: {$resp->error_code}" );
					return "Пользователь {$data['user']['userEmail']} добавлен в группу {$send_data['rid[0]']}. Ответ сервиса: {$resp->error_code}";
				}
				else {
					self::Log( PHP_EOL.'05. Файл justClickSubscribe.php (добавление файла) - ответ сервиса: '. json_encode("Ошибка код:{$resp->error_code} - описание: {$resp->error_text}") );
					return "Ошибка код:{$resp->error_code} - описание: {$resp->error_text}";
				}
	}

/*
	// Вызываем функцию получение списка групп по мейлу клиента и декодируем полученные данные
	$resp = json_decode(Send('http://username.justclick.ru/api/GetLeadGroups', $send_data));
*/

	// 3-ая основная функция: УДАЛЕНИЕ пользователя
	public static function deleteUser($data)
	{
		// ФОРМИРУЕМ ДАННЫЕ ДЛЯ ОТПРАВКИ

				// данные админа
				$user_rs = $data['admin'];

				// объект данных о пользователе (для отправки на сервер)
				$send_data = array(
					'rass_name'  => $data['user']['group'],			// группа, из которой будет удален подписчик
					'lead_email' => $data['user']['userEmail']		// email-адрес пользователя
				);

				// формируем электронную подпись: хешируем логин и ключ админа
				$send_data['hash'] = self::GetHash($send_data, $user_rs);// echo '<pre>'; print_r($send_data); echo '</pre>';  //  посылаемый в АРИ объект с данными

				// пишем лог - перед отправкой данных в АПИ
				self::Log( PHP_EOL.'04. Файл justClickSubscribe.php (удаление файла) - данные в АПИ: '. json_encode($send_data) );

		//	ОТПРАВЛЯЕМ ДАННЫЕ

				// отправляем курлом сформированные данные на нужный адрес СПИ
				// затем декодирум JSON-ответ, и заносим результат в перемнную
				$resp = json_decode( self::Send('http://prodavecokon.justclick.ru/api/DeleteSubscribe', $send_data) );//echo '<pre>'; print_r($resp); echo '</pre>';
		
		//	ПРОВЕРЯЕМ ОТВЕТ СЕРВИСА

				// проверяем правильность подписи (в ответе сервера)
				if( !self::CheckHash($resp, $user_rs) )
				{
					self::Log( PHP_EOL.'05. Файл justClickSubscribe.php (удаление файла) - ответ сервиса: '. json_encode("Ошибка! Подпись к ответу не верна!") );
					echo "Ошибка! Подпись к ответу не верна!";
					exit;
				}

				// если подпись правильная - операция будет выполнена, смотрим ее результат
				if($resp->error_code == 0)
				{
					self::Log( PHP_EOL."05. Файл justClickSubscribe.php (удаление файла) - ответ сервиса: Пользователь {$data['user']['userEmail']} удален из группы {$send_data['rass_name']}. Ответ сервиса: {$resp->error_code}" );
					echo "Пользователь {$data['user']['userEmail']} удален из группы {$send_data['rass_name']}. Ответ сервиса: {$resp->error_code}";
				}
				else
				{
					self::Log( PHP_EOL.'05. Файл justClickSubscribe.php (удаление файла) - ответ сервиса: '. json_encode("Ошибка код:{$resp->error_code} - описание: {$resp->error_text}") );
					echo "Ошибка код:{$resp->error_code} - описание: {$resp->error_text}";
																//если удаляем несуществующего пользователя:	Ошибка код:801 - описание: Subscriber with such address is not found
																//если удаляем из несуществующей группы: 		Ошибка код:800 - описание: Group subscribers is not found
				}
	}

	//************************************** СЛУЖЕБНЫЕ ФУНКЦИИ ОБЩЕГО НАЗНАЧЕНИЯ ***********************************//

	// отправляем запрос в API сервиса 
	private static function Send($url, $data)
	{			
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // выводим ответ в переменную
		
		$res = curl_exec($ch);
		curl_close($ch);

		return $res;
	}

	// формируем подпись к передаваемым в API данным
	private static function GetHash($params, $user_rs)
	{
		$params = http_build_query($params);
		$user_id = $user_rs['user_id'];
		$secret = $user_rs['user_rps_key'];
		$params = "{$params}::{$user_id}::{$secret}";
		
		return md5($params);
	}

	// проверяем полученную подпись к ответу
	private static function CheckHash($resp, $user_rs)
	{		
		$secret = $user_rs['user_rps_key'];
		$code   = $resp->error_code;
		$text   = $resp->error_text;
		$hash   = md5("$code::$text::$secret");

		if($hash == $resp->hash)	return true; 	// подпись верна
		else 						return false; 	// подпись не верна
	}

	// контроль данных: пишем логи
	private static function Log($str)
	{		
		file_put_contents("php/WidgetForms/data_from_client.log", $str, FILE_APPEND );
	}

}