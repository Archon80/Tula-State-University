<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<?=$base_meta?>
</head>
<body>
	<h1><?=$h1?></h1>
	<br/><?=$base_menu_main?><br/>
	<hr/>
	
	<br/><?=$base_content?><br/>
	<hr/>
	<?=$base_footer?>
</body>
</html>
