<!-- подвал -->
<small><a href="contact.php" alt="" target="_blank">Чип и Дэйл</a> &copy;</small>