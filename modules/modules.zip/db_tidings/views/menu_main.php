<a href="index.php">Список статей</a> | 
<a href="article_new.php">Добавить статью</a> | 
<a href="article_parse_file.php">Считать статью из файла</a>

