<!-- служебная мета-информация для каждой страницы -->
<meta content="text/html; charset=utf-8" http-equiv="content-type">	
<link href="public/css/style.css" type="text/css"  rel="stylesheet" media="screen" />
<link href="public/css/style2.css" type="text/css"  rel="stylesheet" media="screen" />