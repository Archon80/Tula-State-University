<?php
	/*
		КОНТРОЛЛЕР (админская часть) - просмотр ВСЕХ статей
	*/
	include_once('model/start.php');

	// call MODEL

		// переменные модульных вставок
		$template_modules['title']	= 'Показ статей';
		$template_modules['h1'] 	= 'Показ статей';

		// переменные текущего сценария
		$current_page_number = isset($_GET['page']) ? (int) $_GET['page'] : 1;		// номер страницы (из гет-параметра, либо по умолчанию  - 1)
		$articles_on_page 	 = 5;													// число статей на одной странице

		$articles   = get_all_articles($current_page_number, $articles_on_page);	// статьи
		$pagination = createPagination($current_page_number, $articles_on_page);	// пагинация										// $objPagin = new Pagination($current_page_number, $articles_on_page); $pagination = $objPagin->createPagination();

		/*
			Блок для отслеживания результатов выполнения операций (добавление, редактирование, удаление статьи)
		*/
		
				$msg = '';												// переменная для отслеживания результатов работы сценариев
				
				// анализируем результат работы сценария добавления новой статьи
				if( isset($_SESSION['article_has_added']) )
				{
					if($_SESSION['article_has_added'] == 'ok')		$msg = ARTICLE_ADD_SUCCESS;
					if($_SESSION['article_has_added'] == 'err')		$msg = ARTICLE_ADD_ERROR;
					if($_SESSION['article_has_added'] == 'double')	$msg = ARTICLE_ADD_DOUBLE;

					unset($_SESSION['article_has_added']);
				}
				
				// анализируем результат работы сценария редактирования отдельной статьи
				if( isset($_SESSION['article_has_changed']) )
				{
					if($_SESSION['article_has_changed'] == 'ok')	$msg = ARTICLE_EDIT_SUCCESS;
					if($_SESSION['article_has_changed'] == 'err')	$msg = ARTICLE_EDIT_ERROR;

					unset($_SESSION['article_has_changed']);
				}
				
				// анализируем результат работы сценария удаления отдельной статьи
				if( isset($_SESSION['article_has_deleted']) )
				{
					if($_SESSION['article_has_deleted'] == 'ok')	$msg = ARTICLE_DELETE_SUCCESS;
					if($_SESSION['article_has_deleted'] == 'err')	$msg = ARTICLE_DELETE_ERROR;

					unset($_SESSION['article_has_deleted']);
				}
				
				// анализируем результат работы сценария чтения статей из файла
				if( isset($_SESSION['article_has_parsed']) )
				{
					if($_SESSION['article_has_parsed'] == 'ok')		$msg = ARTICLE_PARSE_SUCCESS;
					if($_SESSION['article_has_parsed'] == 'err')	$msg = ARTICLE_PARSE_ERROR;

					unset($_SESSION['article_has_parsed']);
				}


	// call VIEW

		// индивидуальный кондент страницы
		$base_content = include_templates(
			'views/tpl_index.html',
			array(
				'articles' 	=> $articles,
				'msg'		=> $msg,
				'pagination'=> $pagination
			)
		);

		echo total_render($base_content, $template_modules);