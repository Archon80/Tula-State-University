<?php
	/*
		КОНТРОЛЛЕР (админская часть) - добавление статей в БД из файла
	*/
	include_once('model/start.php');


	// call MODEL

		// переменные сценария
		$arrArticlesFromFile = array();				// статьи, считанные из файла (в каждой ячейке - отдельная статья)
		$arrTemp = array();							// временный массив для перегонки статей из нумерованного массива в ассоциативный
		$arrArticlesToDB = array();					// ассоциативный массив статей, который будет передан в функцию article_add()
	
		// считываем в нумерованный массив статьи из файла (каждый элемент - статья в виде строки текста с разделителем '|')
		$arrArticlesFromFile = file('data.file') or exit('Error');
		
		// превращаем каждую строку в соответствующим образом форматированный ассоциативный массив, который передаем в функцию добавления статьи
		foreach($arrArticlesFromFile as $arrArticle) {
			
			// получаем статью в виде НУМЕРОВАННОГО массива
			$arrTemp = explode("|", $arrArticle);
			
			// получаем статью в виде АССОЦИАТИВНОГО массива
			$arrArticlesToDB['author'] 		 = $arrTemp[0];
			$arrArticlesToDB['article_name'] = $arrTemp[1];
			$arrArticlesToDB['category'] 	 = $arrTemp[2];
			$arrArticlesToDB['year'] 		 = $arrTemp[3];
			$arrArticlesToDB['status'] 		 = $arrTemp[4];
			$arrArticlesToDB['file_name'] 	 = $arrTemp[5];
			$arrArticlesToDB['article_page'] = $arrTemp[6];
			$arrArticlesToDB['notes'] 		 = $arrTemp[7];
			$arrArticlesToDB['user_id'] 	 = $arrTemp[8];


			// добавляем статью в БД
			$result = article_add($arrArticlesToDB);

			// готовим сообщение о результатах работы сценария
			if($result)		$_SESSION['article_has_parsed'] = 'ok';
			else			$_SESSION['article_has_parsed'] = 'err';
		}

		header('Location: index.php');
		exit();
		//
	
		//echo '<pre>';	print_r($arrArticlesToDB);	echo '</pre>';
	
		

		
		if(  isset($_POST['save']) && isset($_POST['hidden']) )
		{
			// проверяем правильность заполнения форм
			if( checkTitle( $_POST['author'] ) && checkTitle( $_POST['article_name'] ) ) {

				// готовим данные к отдаче в функцию
				$arrDataToUpd = array(
					'id_article' 	 => $_POST['hidden'],
					'author' 		 => $_POST['author'],
					'article_name' 	 => $_POST['article_name'],
					'category' 		 => $_POST['category'],
					'year' 			 => $_POST['year'],
					'status' 		 => $_POST['status'],
					'file_name' 	 => $_POST['filename'],
					'article_page'	 => $_POST['article_page'],
					'notes' 		 => $_POST['notes'],
					'user_id' 		 => $_POST['user_id']
				);

				// обновляем статью
				$result = article_update($arrDataToUpd);

				// готовим сообщение о результатах работы сценария
				if($result)		$_SESSION['article_has_changed'] = 'ok';
				else			$_SESSION['article_has_changed'] = 'err';

				// редиректим пользователя обратно в редактор
				header('Location: index.php');
				exit();
			}
			else
			{
				$id_article 	 = $_POST['hidden'];
				$author 		 = $_POST['author'];
				$article_name 	 = $_POST['article_name'];
				$category 		 = $_POST['category'];
				$year 			 = $_POST['year'];
				$status 		 = $_POST['status'];
				$file_name 		 = $_POST['filename'];
				$article_page	 = $_POST['article_page'];
				$notes 		 	 = $_POST['notes'];
				$user_id 		 = $_POST['user_id'];
				
				$incorrectFormFill = true;
			}
		}
/*
	// call VIEW
		
		// подготовка переменных, необходимых для основного шаблона	
		$base_meta 		= include_templates('views/meta.php');		// занесли в переменную (которая будет видна в итоговой вьюхе) блок мета-информации
		$base_menu_main = include_templates('views/menu_main.php');	// ... меню
		$base_footer 	= include_templates('views/footer.php');		// ... футер

		// основной шаблон (включает 3 блока)
		$tpl_article_edit = include_templates(
			'views/tpl_article_edit.html',
			array(
				'base_meta' 	 	=> $base_meta,
				'base_menu_main' 	=> $base_menu_main,
				'base_footer' 	 	=> $base_footer,
				'incorrectFormFill' => $incorrectFormFill
			)
		);
		
		// установка кодировки
		header('Content-type: text/html; charset=utf-8');

		// выводим вьюху
		echo $tpl_article_edit;
*/