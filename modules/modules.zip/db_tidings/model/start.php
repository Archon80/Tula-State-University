<?php
	// подключение библиотек и выполнение базовых функциональных операций
	include_once('model/lib_db.php');							// подключение к БД
	include_once('model/lib_articles.php');						// операции со статьями
	include_once('model/lib_templation.php');					// шаблонизация
	
	include_once('model/config_messages.php');					// сообщения, выводимые пользователю
	
	
	session_start();											// открытие сессии
	db_connect();												// соединение с БД
	header('Content-type: text/html; charset=utf-8');			// установка кодировки

	

	// подготовка переменных-модулей
	
	$base_meta 		= include_templates('views/meta.php');		// занесли в переменную (которая будет видна в итоговой вьюхе) блок мета-информации
	$base_menu_main = include_templates('views/menu_main.php');	// ... меню
	$base_footer 	= include_templates('views/footer.php');	// ... футер

	$template_modules = array(
		'base_meta' 	 => $base_meta,		
		'base_menu_main' => $base_menu_main,		
		'base_footer' 	 => $base_footer
	);



	// итоговая шаблонизация главного шаблона (идите нахер со своей тавтологией, я все правильно сформулировал)
	
	function total_render($base_content, $template_modules)
	{
		// извлекаем из ассоциативного массива значения, пишем их в переменные, одноименные с ключами массива
		foreach( $template_modules as $k => $v )
		{
			$$k = $v;
		}

		// формируем итоговый шаблон
		$total = include_templates('views/000_index.php',
			array(
				'base_meta' 	 => $base_meta,
				'$title' 	 	 => $$title,
				'h1' 	 		 => $h1,
				'base_menu_main' => $base_menu_main,
				'base_footer' 	 => $base_footer,
				
				'base_content' 	 => $base_content
			)
		);
		// возвращаем итоговый шаблон
		return $total;			
	}