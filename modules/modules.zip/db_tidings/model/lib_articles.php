<?php
	/*
		МОДЕЛЬ: работа со статьями
	*/
	
	// обработка данных, пришедших от пользователя
	function clearData( $data, $type ) {
		
		switch ($type)
		{
			case 's':	$data = stripslashes(trim(htmlspecialchars($data)));	break;	// если тип переменной - строка (по умолчанию)
			case 'i':	$data = abs( (int) $data);								break;	// если тип переменной - целое число
		}
		
		return $data;
	}
	
	// проверка данных из форм на соответствие требованиям
	function checkTitle( $title )
	{
		$title = clearData( $title, 's' );
		
		if ($title == '') {
			return false;
		}
		return true;
	}

	// проверка на дублирование
	function checkDouble( $author, $article_name, $category, $year )
	{
		// получаем статьи из БД (в заданном диапазоне), которые передаем затем во вьюху
		$articles = get_all_articles();

		/*
		$str_to_log = PHP_EOL.date(DATE_RFC2822).PHP_EOL.$author.' '.$article_name.' '.$category.' '.$year.PHP_EOL.PHP_EOL;
		file_put_contents("lib_articles.log", $str_to_log, FILE_APPEND );
		//file_put_contents("lib_articles.log", json_encode($articles), FILE_APPEND );
		*/

		// сравниваем поступившие значения уникальных полей, и имеющиеся в БД
		for ($i = 0; $i < count($articles); $i++)
		{ 
			if (
				$articles[$i]['author'] 		== $author &&
				$articles[$i]['article_name'] 	== $article_name &&
				$articles[$i]['category'] 		== $category &&
				$articles[$i]['year'] 			== $year
			)
			{
				//file_put_contents("lib_articles.log", 'Обнаружены совпадения'.PHP_EOL, FILE_APPEND );
				return true;
			}
			else
			{
				//file_put_contents("lib_articles.log", 'Совпадений не обнаружено'.PHP_EOL, FILE_APPEND );
				return false;
			}
		}		
	}


	// получить список всех статей
	function get_all_articles($current_page_number = '', $articles_on_page = '')
	{
		// подготовка запроса
		$query = ($current_page_number && $articles_on_page) ?
					create_partial_query($current_page_number, $articles_on_page) :
					"SELECT * FROM archives_of_articles ORDER BY id DESC";

		// реализация запроса
		$pile = mysql_query($query);
		if(!$pile && DEBUG_MODE) die('Ошибка базы данных: ' . mysql_error());	// при разработке - вывод ошибки, после - нет
		
		// получение статей от БД
		$articles = from_pile_to_array($pile);
		
		return $articles;			
	}

			// подготовка запроса к выборе всех статей (или статей из указанного диапазона)
			function create_partial_query($current_page_number, $articles_on_page)
			{
				return "SELECT * FROM archives_of_articles ORDER BY id DESC LIMIT $current_page_number, $articles_on_page";
			}
			// обработка запроса (из кучи в массив)
			function from_pile_to_array($result)
			{
				// получаем количество строк, которые вернул запрос
				$n = mysql_num_rows($result);	// ТОЛЬКО для SELECT или SHOW (для INSERT, UPDATE, REPLACE и DELETE - mysql_affected_rows() )
				
				// формируем пустой массив для выкачиваемых из БД статей
				$articles = array();

				// обрабатываем ответ БД (набор массивов - по каждой строке), превращая его в набор массивов
				for ($i = 0; $i < $n; $i++)
				{
					$row = mysql_fetch_assoc($result);
					$articles[] = $row;
				} // или while ($row = mysql_fetch_array($result)) { $articles[] = $row; }
			
				// возвращаем массив статей (который сможет обработать РНР)
				return $articles;
			}
	
	// получить одну статью из базы
	function article_get($id_article)
	{
		// безопасная обработка данных - в модели: чтобы можно было вызывать функцию из разных мест
		$id_article = clearData( $id_article, 'i' );
		
		// подготовка запроса, запрос и контроль его исполнения
		$query = "SELECT * FROM archives_of_articles WHERE id=$id_article";
		$result = mysql_query($query);
		if(!$result && DEBUG_MODE) die('Ошибка базы данных: ' . mysql_error());
		
		// преобразуем ответ БД из аморфной херни в массив
		$article = mysql_fetch_assoc($result);
		
		// возвращаем массив статей (который сможет обработать РНР)
		return  $article;
	}


	// добавить одну статью в БД
	function article_add($arrDataToAdd) {
		
		//echo '<pre>'; print_r($arrDataToAdd); echo '<pre>';//				exit();

		// проверка условий - в модели, чтобы вызывать данную функцию из разных мест
		$dt				= time();
		$author 		= ($arrDataToAdd['author'] 		!= '') ? clearData( $arrDataToAdd['author'], 	  	's' ) : $arrDataToAdd['author'];
		$article_name	= ($arrDataToAdd['article_name']!= '') ? clearData( $arrDataToAdd['article_name'],	's' ) : $arrDataToAdd['article_name'];
		$category 		= ($arrDataToAdd['category'] 	!= '') ? clearData( $arrDataToAdd['category'], 		's' ) : $arrDataToAdd['category'];
		$year			= ($arrDataToAdd['year'] 		!= '') ? clearData( $arrDataToAdd['year'], 			'i' ) : $arrDataToAdd['year'];
		$status 		= ($arrDataToAdd['status'] 		!= '') ? clearData( $arrDataToAdd['status'], 		's' ) : $arrDataToAdd['status'];
		$file_name 		= ($arrDataToAdd['file_name'] 	!= '') ? clearData( $arrDataToAdd['file_name'],		's' ) : $arrDataToAdd['file_name'];
		$article_page 	= ($arrDataToAdd['article_page']!= '') ? clearData( $arrDataToAdd['article_page'], 	'i' ) : $arrDataToAdd['article_page'];
		$notes 			= ($arrDataToAdd['notes'] 		!= '') ? clearData( $arrDataToAdd['notes'], 		's' ) : $arrDataToAdd['notes'];
		$user_id 		= ($arrDataToAdd['user_id'] 	!= '') ? clearData( $arrDataToAdd['user_id'], 		's' ) : $arrDataToAdd['user_id'];

		$sql = "INSERT INTO archives_of_articles 
							(datetime, author, article_name, category, year, status, file_name, article_page, notes, user_id)
						VALUES 
							('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";

		$query = sprintf($sql, 
						 mysql_real_escape_string($dt),
						 mysql_real_escape_string($author),
						 mysql_real_escape_string($article_name),
						 mysql_real_escape_string($category),
						 mysql_real_escape_string($year),
						 mysql_real_escape_string($status),
						 mysql_real_escape_string($file_name),
						 mysql_real_escape_string($article_page),
						 mysql_real_escape_string($notes),
						 mysql_real_escape_string($user_id)
					);

		$result = mysql_query($query);												// выборка из БД

		if(!$result && DEBUG_MODE) exit ('Ошибка базы данных ' . mysql_error());	// проверка результата запроса к БД

		return true;
	}

	

	// обновление статьи
	function article_update($arrDataToUpd) {

		// проверка условий - в модели, чтобы вызывать данную функцию из разных мест
		$id_article	= clearData( $arrDataToUpd['id_article'], 'i' );

		//echo '<pre>';	print_r($arrDataToUpd);	echo '</pre>';
		
		$author 		= ($arrDataToUpd['author'] 		!= '') ? clearData( $arrDataToUpd['author'], 	  	's' ) : $arrDataToUpd['author'];
		$article_name	= ($arrDataToUpd['article_name']!= '') ? clearData( $arrDataToUpd['article_name'],	's' ) : $arrDataToUpd['article_name'];
		$category 		= ($arrDataToUpd['category'] 	!= '') ? clearData( $arrDataToUpd['category'], 		's' ) : $arrDataToUpd['category'];
		$year			= ($arrDataToUpd['year'] 		!= '') ? clearData( $arrDataToUpd['year'], 			's' ) : $arrDataToUpd['year'];
		$status 		= ($arrDataToUpd['status'] 		!= '') ? clearData( $arrDataToUpd['status'], 		's' ) : $arrDataToUpd['status'];
		$file_name 		= ($arrDataToUpd['file_name'] 	!= '') ? clearData( $arrDataToUpd['file_name'],		's' ) : $arrDataToUpd['filename'];
		$article_page 	= ($arrDataToUpd['article_page']!= '') ? clearData( $arrDataToUpd['article_page'], 	's' ) : $arrDataToUpd['article_page'];
		$notes 			= ($arrDataToUpd['notes'] 		!= '') ? clearData( $arrDataToUpd['notes'], 		's' ) : $arrDataToUpd['notes'];
		$user_id 		= ($arrDataToUpd['user_id'] 	!= '') ? clearData( $arrDataToUpd['user_id'], 		's' ) : $arrDataToUpd['user_id'];

		// Запрос на изменение 
		$t = 	"UPDATE archives_of_articles
				SET
					author		 ='%s',
					article_name ='%s',
					category	 ='%s',
					year		 ='%s',
					status		 ='%s',
					file_name	 ='%s',
					article_page ='%s',
					notes		 ='%s',
					user_id		 ='%s'
				WHERE id='%d'";

		// отсюда все убрали так как переменные уже готовы и полностью безопасны
		$query = sprintf(
						$t,

						$author,
						$article_name,
						$category,
						$year,
						$status,
						$file_name,
						$article_page,
						$notes,
						$user_id,

						$id_article
						);
		
		$result = mysql_query($query);

		if (!$result && DEBUG_MODE)	exit('Ошибка базы данных: ' . mysql_error());
		
		return true;
	}

	

	// удаление статьи
	function article_delete($id_article) {
		
		if($id_article == '' && DEBUG_MODE) exit('Возникла ошибка при удалении статьи: в функцию article_delete() не передан идентификатор статьи');
		
		// безопасная обработка данных - в модели: чтобы можно было вызывать функцию из разных мест
		$id_article = clearData( $id_article, 'i' );
		
		$sql = "DELETE FROM archives_of_articles WHERE id=$id_article";

		$result = mysql_query($sql);

		if($result)		return true;
		else			return false;
	}


	// ормирование пагинации
	function createPagination($a, $b)
	{
		$current_page_number = $a;			// номер текущей страницы
		$articles_on_page	 = $b;			// количество статей, выводимых на странице
		$count_of_articles_in_db;						// общее количество статей в базе
		$pagin_pages;						// количество страниц в пагинации
		$start_article 		 = $articles_on_page * ($current_page_number - 1);// номер статьи, с которой надо начинать выборку из БД
		$total 					= '';		// строка для суммирования тегов пагинации

		$count_of_articles_in_db = get_count_of_strings_of_db("archives_of_articles");	// всего статей в базе

		// делим общее число статей на число статей на странице
		$pagin_pages = ceil( $count_of_articles_in_db / $articles_on_page );		// в бОльшую сторону, т.к. на последней странице - тоже статьи, пусть и не полностью ее заполняют

		// формируем пагинацию списка статей - цикл строго от 1 до <= общего количества страниц пагинации
		for($i = 1; $i <= $pagin_pages; $i++)
		{
			if($current_page_number == $i)	$total .= "<b> $i </b>";
			else							$total .= "<a href=\"index.php?page=$i\"> $i </a>";
		}

		return $total;
	}

			// узнать количество строк в БД: принимает название таблицы, возвращает количество строк
			function get_count_of_strings_of_db($db_name)
			{
				$pile = mysql_query("SELECT count(*) FROM $db_name");	// (или count(*) as cnt) считаем общее количество страниц, именуем это число для дальнейшего использования
				if(!$pile) die ('Ошибка базы данных: ' . mysql_error());
				
				$count_of_strings_of_db = mysql_fetch_row($pile);	// нумерованный массив из одной пары "ключ : значение" (сколько всего страниц в базе)

				return $count_of_strings_of_db[0];
			}