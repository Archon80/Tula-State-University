<?php
	/*
		МОДЕЛЬ: подключение к БД
	*/

	// подключение к БД
	function db_connect()
	{
		// устанавливаем начальные значения для подключения к БД
		define('DB_HOST', 'localhost');
		define('DB_LOGIN', 'root');
		define('DB_PASSWORD', '');
		define('DB_NAME', 'YBS');

		// настройка языка и временной зоны
		setlocale(LC_ALL, 'ru_RU.65001');
		date_default_timezone_set('Europe/Moscow');
		
		// подключение к БД
		mysql_connect(DB_HOST, DB_LOGIN, DB_PASSWORD) or die('No connect with data base');
		mysql_query('SET NAMES utf8');
		mysql_select_db(DB_NAME) or die('No data base');
	}
	
	
/*
	МОЙ ЛОКАЛХОСТ
	-------------
	define('DB_HOST', 'localhost');
	define('DB_LOGIN', 'root');
	define('DB_PASSWORD', '');
	define('DB_NAME', 'YBS');

	МОЙ сайт (цветочный)
	--------------------
	define('DB_HOST', 'localhost');
	define('DB_LOGIN', 'zarchon_80');
	define('DB_PASSWORD', '290980');
	define('DB_NAME', 'zarchon_80');

	ТВОЙ сайт (Петерхост)
	---------------------
	define('DB_HOST', 'mysql.boryak.z8.ru');
	define('DB_LOGIN', 'dbu_boryak_3');
	define('DB_PASSWORD', '5NPVpkC3XBL');
	define('DB_NAME', 'db_boryak_3');
	
	Еще раз перезатрешь мои данные - убью!!! )))
*/
