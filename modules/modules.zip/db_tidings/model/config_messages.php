<?php
	/*
		МОДЕЛЬ: выводимые на сайте сообщения
	*/
	define('DEBUG_MODE', true);				// переключатель отладочного режима

	// работа со статьями
	define('ARTICLE_ADD_SUCCESS', '<b style="color: green;">Новая статья успешно добавлена!</b>');
	define('ARTICLE_ADD_ERROR',   '<b style="color: red;">Новая статья НЕ была добавлена.</b>');
	define('ARTICLE_ADD_DOUBLE',  '<b style="color: red;">Такая статья уже существует!</b>');

	define('ARTICLE_EDIT_SUCCESS', '<b style="color: green;">Статья успешно изменена!</b>');
	define('ARTICLE_EDIT_ERROR',   '<b style="color: red;">Статья НЕ была изменена.</b>');

	define('ARTICLE_DELETE_SUCCESS', '<b style="color: green;">Статья успешно удалена!</b>');
	define('ARTICLE_DELETE_ERROR',   '<b style="color: red;">Статья НЕ была удалена.</b>');

	define('ARTICLE_PARSE_SUCCESS', '<b style="color: green;">Статьи успешно считаны из файла</b>');
	define('ARTICLE_PARSE_ERROR',   '<b style="color: red;">Статьи НЕ были считаны из файла.</b>');